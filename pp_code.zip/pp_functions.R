#######################################################################
# This library contains functions for the entry model
# - 
# It also calls the mvtnorm, MASS, and nleqslv libraries
######################################################################

# Downloaded libraries
library(mvtnorm)
library(MASS)
library(nleqslv)
library(pracma)

###############################################################################
# This function solves the Perry-Porter capital stocks model for a given
# vector of capital (k), demand parameters (a and b), and common MC (c).
# Written intially for Miller-Podwol hedging paper.
###############################################################################

f.capstockequil <- function(k,a,b,c){  
  beta = b*k/(b*k+1)
  B = sum(beta)
  Q = ((a-c)/b)*(B/(1+B))
  P = (a+B*c)/(1+B)
  s = beta/B
  E = 1/B
  H = sum(s^2)
  W = (a-c)^2/(2*b)*(1/(1+E) + H/((1+E)^2))
  pi = Q*s*P - (Q*s)*c - (Q*s)^2/(2*k)
  PI = sum(pi)
  CS = W-PI  
  mc = Q*s/k
  return(list(s=s,p=P,q=Q,mc=mc,cs=CS,pi=pi))
}


###################################################################
# This function calibrates Perry-Porter capital stocks model 
####################################################################

f.capstockcal <- function(s,p,q){
  
  #Number of firms
  nfirm <- length(s)
  
  #Parameters: (a,b,k)
  start = c(p*2,1,rep(1/nfirm,nfirm))    
  data <- c(p,q,s)
  
  #Calibration
  cal = lsqnonlin(f.loss2,start,data=data)
  
  a1=cal$x[1]
  b1=cal$x[2]
  c1=0
  k1=cal$x[3:length(cal$x)]
  
  econstat <- f.capstockequil(k1,a1,b1,c1)
  
  return(list(a=a1,b=b1,type=k1,cs=econstat$cs,pi=econstat$pi))
}


###################################################################
# These two functions are for use in Perry-Porter calibration.
###################################################################

f.loss2 <- function(start,data) {
  pred = f.losssub(start=start)$pred
  return(1-pred/data)
}   

f.losssub <- function(start){
  a=start[1]
  b=start[2]
  k=start[3:length(start)]
  c=0
  pred1 = f.capstockequil(k,a,b,c)
  s1 = pred1$s
  p1 = pred1$p
  q1 = pred1$q
  mc1 = pred1$mc
  m1 = sum(s1*(p1-mc1)/p1)
  pred = c(p1,q1,s1)
  return(list(pred=pred,s=s1,p=p1,q=q1,mc=mc1,m=m1))
}


