/*==========================================================
 * c_contrMap_rcnl_BHRW.c - modifies Nevo (2001) contraction mapping
 * for the the Brunner, Heiss, Romahn, Weiser (2017) adjustment.
 *
 * Inputs include:
 *      tol = scalar indicating the contraction mapping tolerance
 *      maxiter = scalar indicating maximimum number of iterations
 *      expmvalold = vector as in Nevo (2001) Matlab code
 *      expmu = matrix as in Nevo (2001) Matlab code
 *      cdindex = vector as in Nevo (2001) Matlab code
 *      rho = NUISANCE PARAMETER
 *
 * Output is a vector, named expmval internally, that is the exponentiated 
 * mean consumer valuations that align observed and predicted shares given 
 * the expmu matrix (and thus the candidate nonlinear parameters).   
 * Auxiliary output vectors are the market-specific tolerances and 
 * iterations.
 *
 * The calling syntax is:
 *
 * [expmval,mkttol,mktiter] =contMap_blp_BHRW(tol,maxiter,expmvalold,expmu,cdindex,rho)
 *
 *========================================================*/
/* $Written by Nathan Miller, January 30, 2016$ */
/* $Adjusted by Nathan Miller, November 14, 2018, for BHRW$ */

#include "mex.h"
#include "math.h"


//mexPrintf("3 to the power of 12 equals: %f\n",pow(3,12));

/*==========================================================
 * The printArray function makes it simpler to print arrays,
 * thereby faciliating the debugging process. 
 *========================================================*/
void printArray(int size, char* name, double *array) {
    int j;
    for (j=0; j<size; j++){
        mexPrintf("%s[%d]=%f\n", name, j, array[j]);
    }
}


/*==========================================================
 * The contrMap function contains the computational routine.
 *========================================================*/
void contrMap(double tol, double maxiter, 
        double *expmvalold, double *expmval, double *expmu,
        mwSize nJ, mwSize nI, mwSize nM, 
        double *cdindex, double *shares, double rho, 
        double *mktnorm, double *mktiter)
{
    /* Assigning variable names */
    mwSize j;
    mwSize i;
    mwSize mkt;
    mwSize ii;
    mwSize k;
    mwSize nJM; 
    int mStart;
    int mEnd;
    double invnI;  
    double maxabsdev;
    double absdev;
    double norm;      
    int iter;
    mxArray *expmvaloldMx;
    double  *expmvaloldM; 
    mxArray *sharesMx;
    double  *sharesM;     
    mxArray *expmuMx;
    double  *expmuM;     
    double   sumVal;    
    mxArray *exputilMx;
    double  *exputilM;    
    mxArray *pShares0iMx;
    double  *pShares0iM;     
    mxArray *pSharesMx;
    double  *pSharesM; 
    mxArray *expmvalMx;
    double  *expmvalM;    
    double  oneLessRho;
    double  invOneLessRho;

    mxArray *mvaloldMx;
    double  *mvaloldM; 
    mxArray *mvalMx;
    double  *mvalM;     
    
    // Moves division outside the loops //
    invnI = 1.0 / (double)nI;
    oneLessRho = (1-rho); 
    invOneLessRho = 1 / (double)oneLessRho;
    
    //mexPrintf("invnI: %f \n",invnI);
    //mexPrintf("nI: %d \n",nI);
    //printArray(nM, "cdindex", cdindex);    
    //mexPrintf("oneLessRho: %f \n",oneLessRho);
    //mexPrintf("invOneLessRho: %f \n",invOneLessRho);
    
    /*==========================================================
     * Looping through markets creates time savings because the iterations
     * for each market end when the convergence criterion is met within the
     * market, rather than when it is met across all markets.
     *========================================================*/    
    for (mkt=0; mkt<nM; mkt++) {
        
        /* Start/stop variables to help create market-specific objects */
        if (mkt==0){
            mStart = 0;
            nJM = cdindex[mkt];
        }
        else {
            mStart = cdindex[mkt-1];
            nJM = cdindex[mkt] - cdindex[mkt-1];
        }           
        mEnd = cdindex[mkt];
            
        /* Create market-specific objects: expmvalold, expmu, shares*/
        expmvaloldMx = mxCreateDoubleMatrix((mwSize)nJM,1,mxREAL); 
        expmvaloldM  = mxGetPr(expmvaloldMx);

        sharesMx = mxCreateDoubleMatrix((mwSize)nJM,1,mxREAL); 
        sharesM  = mxGetPr(sharesMx);
            
        expmuMx = mxCreateDoubleMatrix(nJM*nI,1,mxREAL); 
        expmuM  = mxGetPr(expmuMx);            
                 
        /* Fill in market-specific objects with input data*/            
        for (j=mStart; j<mEnd; j++) {            
            expmvaloldM[j-mStart] = expmvalold[j];  
            //mexPrintf("expmvaloldM[%d]: %f \n",j-mStart,expmvaloldM[j-mStart]);
            sharesM[j-mStart] = shares[j];  
            for (i=0; i<nI; i++){
                expmuM[nJM*i+j-mStart] = expmu[nJ*i+j];  
                //mexPrintf("expmuM[%d]: %f \n",nJM*i+j-mStart,expmuM[nJM*i+j-mStart]);
            }
        }
        
        /* Market-specific intermediate data sets */
        exputilMx = mxCreateDoubleMatrix(nJM*nI,1,mxREAL); 
        exputilM  = mxGetPr(exputilMx);  
        
        pShares0iMx = mxCreateDoubleMatrix(nI,1,mxREAL); 
        pShares0iM  = mxGetPr(pShares0iMx);  

        pSharesMx = mxCreateDoubleMatrix(nJM,1,mxREAL); 
        pSharesM  = mxGetPr(pSharesMx);    

        expmvalMx = mxCreateDoubleMatrix(nJM,1,mxREAL); 
        expmvalM  = mxGetPr(expmvalMx);            
        
        mvalMx = mxCreateDoubleMatrix(nJM,1,mxREAL); 
        mvalM  = mxGetPr(mvalMx); 
        
        mvaloldMx = mxCreateDoubleMatrix(nJM,1,mxREAL); 
        mvaloldM  = mxGetPr(mvaloldMx);       
        
        
         /*==========================================================
         * Conducting the market-specific contraction mapping.
         *========================================================*/  
        iter = 0;
        norm = 1.0;       
        while (norm>tol && iter<maxiter) {        
            maxabsdev=0;
            
            // Calculating market-individual-specific outside good shares //
            // Equation (20) in BHRW (2017)            
            for (ii=0; ii<nI; ii++) {
                sumVal = 0;
                for (k=0; k<nJM; k++) {
                    exputilM[(ii*nJM)+k] = expmvaloldM[k]*expmuM[(ii*nJM)+k];
                    sumVal = sumVal + exputilM[(ii*nJM)+k];
                }
                pShares0iM[ii] = 1 / (1 + sumVal);                
            }

            /*========================================================= 
            * Aggregates to obtain predicted market-specific shares,
            * calculates expmval and deviations, and updates expmvalold
            *=========================================================*/
            for (k=0; k<nJM; k++) {
                pSharesM[k]=0;
                for (ii=0; ii<nI; ii++) {
                    // Equation (19) from BHRW (2017), RHS denominator
                    pSharesM[k] = pSharesM[k]+(expmuM[(ii*nJM)+k]*pShares0iM[ii]*invnI);
                }
                
                // Equation (19) from BHRW (2017)
                expmvalM[k] = sharesM[k]/pSharesM[k];

                // Checking closesness relative to tolerance and iterating
                absdev = fabs(expmvalM[k]-expmvaloldM[k]);
                if (absdev>maxabsdev){
                    maxabsdev=absdev;
                }
                expmvaloldM[k]=expmvalM[k];
            }
            //mexPrintf("maxabsdev: %f \n",maxabsdev);
            //printArray(nJM,"sharesM", sharesM);
            //printArray(nJM,"pSharesM", pSharesM);
            iter = iter+1;
            norm = maxabsdev;
        }

        /*=========================================================
         * Slots market-specific expmvalM into expmval after convergence.
         * The vector exmpval is what is returned to the gateway function
         * and also to Matlab.
         *=========================================================*/
        for (j=mStart; j<mEnd; j++) {            
            expmval[j] = expmvalM[j-mStart];  
        }
        mktnorm[mkt]=norm;
        mktiter[mkt]=iter;
        
        //mexPrintf("nJM: %d \n",nJM);
        //mexPrintf("mStart: %d \n",mStart);
        //mexPrintf("mEnd: %d \n",mEnd);
        //printArray(nJM,"expmvaloldM", expmvaloldM);
        //printArray(nJM,"sharesM", sharesM);
        //printArray(nJM*nI,"expmuM", expmuM);
        //printArray(nJM*nI,"exputilM", exputilM);
        //printArray(nJM*nI,"pShares0iM", pShares0iM);
        //printArray(nJM,"pSharesM", pSharesM);        
        //printArray(nJM,"expmvalM", expmvalM);   
        
        /* Destroying market-specific data to prevent memory leaks */
        mxDestroyArray(expmvaloldMx);
        mxDestroyArray(expmuMx);
        mxDestroyArray(sharesMx);
        mxDestroyArray(exputilMx);
        mxDestroyArray(pShares0iMx);        
        mxDestroyArray(pSharesMx);
        mxDestroyArray(expmvalMx);  
        mxDestroyArray(mvalMx);  
        mxDestroyArray(mvaloldMx);
        
        /* *** MARKET LOOP ENDS *** */
    }
   
   //mexPrintf("Hello!\n");
   //mexPrintf("norm %f \n",norm);
   //mexPrintf("iter %d \n",iter);
   //printArray(nM, "cdindex", cdindex);    
   //printArray(nJ, "expmvalold", expmvalold);
   //printArray(nJ*nI, "expmu", expmu);
   //printArray(nJ, "expmval", expmval);

/* *** END OF contrMap FUNCTION *** */
}
    



/*====================================================================
 * mexFunction is the gateway beween Matlab and the contrMap function.
 *===================================================================*/
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[])
{
    double tol;          /* contraction mapping tolerance */
    double maxiter;      /* max iterations in contraction mapping */    
    double *expmvalold;  /* initial vector of mean valuations */
    double *expmu;       /* matrix of individual-specific deviations */   
    double *cdindex;     /* vector identifies last obs of each market */
    double *shares;      /* vector of observed market shares */
    double rho ;         /* nested logit parameter */

    size_t nJ ;          /* number of product-mkt observations */
    size_t nI ;          /* number of individual draws  */
    size_t nM ;          /* number of markets  */    
    double *expmval;     /* output vector of updated mean valuations */    
    double *mktnorm;     /* output vector of market tolerances */    
    double *mktiter;     /* output vector of market # iterations */  
    
    /* get the value of tol  */
    tol = mxGetScalar(prhs[0]);

    /* get the value of maxiter  */
    maxiter = mxGetScalar(prhs[1]);    
    
    /* create a pointer to the real exmvalold data  */
    expmvalold = mxGetPr(prhs[2]);

    /* get dimensions of the inputs */
    nJ = mxGetM(prhs[3]);
    nI = mxGetN(prhs[3]);    
    nM = mxGetM(prhs[4]);
    
    // mexPrintf("nJ=%d; nI=%d; nM=%d\n", nJ, nI, nM);
    
    /* create a pointer to the real expmu data  */
    expmu = mxGetPr(prhs[3]);

    /* create a pointer to the real cdindex data */
    cdindex = mxGetPr(prhs[4]);    

    /* create a pointer to the real share data  */
    shares = mxGetPr(prhs[5]);      

    /* create a pointer to the nested logit parameter */
    rho = mxGetScalar(prhs[6]);
        
    /* create the output data 1 */
    plhs[0] = mxCreateDoubleMatrix((mwSize)nJ,1,mxREAL);

    /* create the output data 2 */
    plhs[1] = mxCreateDoubleMatrix((mwSize)nM,1,mxREAL);    
 
    /* create the output data 2 */
    plhs[2] = mxCreateDoubleMatrix((mwSize)nM,1,mxREAL);      
    
    /* get a pointer to the real data in the output matrix */
    expmval = mxGetPr(plhs[0]);

    /* get a pointer to the realized tolerance */
    mktnorm = mxGetPr(plhs[1]);

    /* get a pointer to the realized tolerance */
    mktiter = mxGetPr(plhs[2]);    
    
    /* call the computational routine */
    contrMap(tol,maxiter,expmvalold,expmval,expmu,
            (mwSize)nJ,(mwSize)nI,(mwSize)nM,
            cdindex,shares,rho,mktnorm,mktiter);    

    
    
  //  printArray(nJ, "final expmval", expmval);
  //  printArray(nJ, "final exputil", exputil);
  //  mexPrintf("Done!\n");   
    
    
}
  
    
  