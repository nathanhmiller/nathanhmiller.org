########################################################################
# This program illustrates how the nested logit functions can be called.
#   See nlfunctions.R for more details.
# Updated August 20, 2019.
########################################################################

rm(list = ls())

  
source("nlfunctions.R")

delta = c(-0.5269,-0.5269,-1.0050,-1.2822)
group = cbind(c(1,1,2,2),c(1,1,1,1))
sigma = c(0.6,0.3)
sj = c(0.1750,0.1750,0.1,0.05)
  
#Shares using structural parameters as inputs
f.share(delta=delta,sigma=sigma,group=group)  

#Shares using shares as inputs
f.share2(sj,group)
  
#Conditional derivatives using structural parameters as inputs
f.condDqddelta(delta,sigma,group,0,sj)  

#Conditional derivatives using shares as inputs
f.condDqddelta(delta,sigma,group,1,sj)  
  

    