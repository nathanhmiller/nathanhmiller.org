############################################
# This program generates numerical results #
# for the Miller-Sheu entry project        #
############################################

rm(list = ls())

#Setting path
path <- " ... "
setwd(path)

#Reading the relevant libraries
source("pp_functions")


#############################################################################
# Initial Data Specification:
#############################################################################

basecal <- list("shares"=c(0.3,0.3,0.4))

basecal$markup <- 0.5
basecal$fNum <- fNum <- c(1,2,3)
basecal$fNum2 <- c(1,1,3)
basecal$mktP <- 1
basecal$mktQ <- 1


##########################################################################
# Initial Equilibrium
##########################################################################

premerger <- f.capstockcal(s=basecal$shares,p=basecal$mktP,q=basecal$mktQ)

##########################################################################
# Looping over entrant types, etype=[0,min(merging firm types)], and 
# computing equilibrium in each case, with and without merger.
##########################################################################


combine <- aggregate(precourn$type,by=list(basecal$fNum2),FUN=sum)$x

postmerger <- f.capstockequil(k=type2_pp,a=precourn$a,b=precourn$b,c=0)

print(premerger)
print(postmerger)


